﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IFM3GroupProject.Models
{
    public class Accommodation_Owner
    {
        private int OwnerID;
        private int ServiceProviderNumber;
        private string OwnerName;
        private string OwnerSurname;
        private string OwnerEmail;
        private char AuthenticationLevel;
        private string ContactNumber;
        private string Password;
        private string Gender;

        Accommodation_Owner()
        {
            OwnerID = 0;
            ServiceProviderNumber = 0;
            OwnerName = "";
            OwnerSurname = "";
            OwnerEmail = "";
            AuthenticationLevel = 'O';
            ContactNumber = "";
            Password = "";
            Gender = "";
        }
        
        Accommodation_Owner(int ID, int SP_Number, string Gender, string Name, string Surname, string Email, string Password)
        {
            this.OwnerID = ID;
            this.ServiceProviderNumber = SP_Number;
            this.Gender = Gender;
            this.OwnerName = Name;
            this.OwnerSurname = Surname;
            this.OwnerEmail = Email;
            this.AuthenticationLevel = 'O';
            this.Password = Password;
        }

        public int getID()
        {
            return OwnerID;
        }

        public int getServiceProvNumber()
        {
            return ServiceProviderNumber;
        }

        public string getGender()
        {
            return Gender;
        }

        public string getName()
        {
            return OwnerName;
        }

        public string getSurname()
        {
            return OwnerSurname;
        }

        public string getEmail()
        {
            return OwnerEmail;
        }

        public string getPassword()
        {
            return Password;
        }

        public char getAuthLevel()
        {
            return AuthenticationLevel;
        }
    }
}