﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IFM3GroupProject.Models
{
    public class Student
    {
        //Declaration of variables
        private int StudentID;

        private int StudentNumber;

        private string FirstName;

        private string Surname;

        private string Gender;

        private string Email;

        private string ContactNumber;

        private char AutheticationLevel;

        private string Password;

        //Default Constructor
        public Student()
        {
            StudentID = 0;
            StudentNumber = 0;
            FirstName = "";
            Surname = "";
            Gender = "";
            Email = "";
            ContactNumber = "";
            AutheticationLevel = 'S';
            Password = "";
        }

        //Constructor with parameters
        public Student(int stdID, int stdnum, string fname, string lname, string gender, string email, string contactNo, string password)
        {
            this.StudentID = stdID;
            this.StudentNumber = stdnum;
            this.FirstName = fname;
            this.Surname = lname;
            this.Gender = gender;
            this.Email = email;
            this.ContactNumber = contactNo;
            this.AutheticationLevel = 'S';
            this.Password = password;

        }

        //Getters 
        public int getStudentNumber()
        {
            return StudentNumber;
        }

        public int getStudentID()
        {
            return StudentID;
        }

        public string getFirstName()
        {
            return FirstName;
        }

        public string getSurname()
        {
            return Surname;
        }


        public string getGender()
        {
            return Gender;
        }

        public string getEmail()
        {
            return Email;

        }


        public string getPassword()
        {
            return Password;
        }

    }
}