﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IFM3GroupProject.Models
{
    public class Accommodation_Officer
    {
        private int OfficerID;
        private int EmployeeNumber;
        private string OfficerName;
        private string OfficerSurname;
        private string OfficerEmail;
        private char AuthenticationLevel;
        private string ContactNumber;
        private string Password;
        private string Gender;

        Accommodation_Officer()
        {
            OfficerID = 0;
            EmployeeNumber = 0;
            OfficerName = "";
            OfficerSurname = "";
            OfficerEmail = "";
            AuthenticationLevel = 'A';
            ContactNumber = "";
            Password = "";
            Gender = "";
        }
        Accommodation_Officer(int ID, int EmployeeNumber, string Gender, string Name, string Surname, string Email, string Password)
        {
            this.OfficerID = ID;
            this.EmployeeNumber = EmployeeNumber;
            this.Gender = Gender;
            this.OfficerName = Name;
            this.OfficerSurname = Surname;
            this.OfficerEmail = Email;
            this.AuthenticationLevel = 'A';
            this.Password = Password;
        }

        public int getID()
        {
            return OfficerID;
        }

        public int getEmployeeNumber()
        {
            return EmployeeNumber;
        }

        public string getGender()
        {
            return Gender;
        }

        public string getName()
        {
            return OfficerName;
        }

        public string getSurname()
        {
            return OfficerSurname;
        }

        public string getEmail()
        {
            return OfficerEmail;
        }

        public string getPassword()
        {
            return Password;
        }

        public char getAuthLevel()
        {
            return AuthenticationLevel;
        }
     }
}